// Example result object
const queryResult = {
  took: 35,
  timed_out: false,
  _shards: { total: 5, successful: 5, skipped: 0, failed: 0 },
  hits: {
    total: { value: 2, relation: 'eq' },
    max_score: 1,
    hits: [
      { _id: '1', _source: { name: 'John', age: 30 } },
      { _id: '2', _source: { name: 'Jane', age: 25 } }
    ]
  }
};

// Function to parse and combine hits into a single string
function combineHits(queryResult) {
  let fullContents = ""; // Initialize an empty string to store combined contents

  if (queryResult.hits && queryResult.hits.hits) {
    // Loop over the hits array
    queryResult.hits.hits.forEach(hit => {
      // Convert each hit object to a string and append it to the fullContents
      fullContents += JSON.stringify(hit) + "\n"; // Add a newline for separation
    });
  } else {
    // If no hits, return an appropriate message
    fullContents = "No hits found.";
  }

  return fullContents;
}

// Call the function and store the result in a string
const resultString = combineHits(queryResult);

// Output the result string
console.log(resultString);