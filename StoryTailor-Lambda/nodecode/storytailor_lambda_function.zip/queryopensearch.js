import https from 'https';
import { defaultProvider } from '@aws-sdk/credential-provider-node'; // For obtaining credentials automatically
import { SignatureV4 } from '@aws-sdk/signature-v4';
import { HttpRequest } from '@aws-sdk/protocol-http';
import { Sha256 } from '@aws-crypto/sha256-browser';

// Replace with your OpenSearch domain and index
const domain = 'search-storytailor2-y3v3y3gbfsfuyznpjhnvwx6vde.aos.us-west-2.on.aws';
const indexName = 'securedata';
const region = 'us-west-2'; // Your AWS region

/**
 * Function to query data within specific time ranges
 * @param {string} range - Time range ('day', 'week', 'month', 'year', 'all')
 */
async function queryOpenSearch(range) {
  const end = new Date().toISOString(); // Current time in ISO 8601 format
  let start;

  switch (range) {
    case 'day':
      start = new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(); // Last 24 hours
      break;
    case 'week':
      start = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(); // Last 7 days
      break;
    case 'month':
      start = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString(); // Last 30 days
      break;
    case 'year':
      start = new Date(Date.now() - 365 * 24 * 60 * 60 * 1000).toISOString(); // Last year
      break;
    case 'all':
      start = '1970-01-01T00:00:00Z'; // Start from epoch time
      break;
    default:
      throw new Error('Invalid range provided');
  }

  // Elasticsearch query DSL for range filtering
  const query = {
    query: {
      range: {
        'Timestamp': {
          gte: start,
          lte: end
        }
      }
    }
  };

  const requestBody = JSON.stringify(query);

  // Construct the OpenSearch endpoint
  const endpoint = new URL(`https://${domain}/${indexName}/_search`);

  // Create the signed request
  const request = new HttpRequest({
    method: 'POST',
    hostname: endpoint.hostname,
    path: endpoint.pathname,
    headers: {
      host: endpoint.hostname,
      'Content-Type': 'application/json'
    },
    body: requestBody
  });

  try {
    // Sign the request using Signature V4
    const credentials = await defaultProvider()();
    const signer = new SignatureV4({
      credentials,
      service: 'es',
      region,
      sha256: Sha256
    });

    const signedRequest = await signer.sign(request);

    // Send the request and fetch the response
    const response = await makeHttpRequest(signedRequest);
    console.log('Query result:', response.body);
  } catch (error) {
    console.error('Error querying OpenSearch:', error);
  }
}

// Function to execute the signed HTTP request
const makeHttpRequest = (request) => {
  return new Promise((resolve, reject) => {
    const req = https.request({
      hostname: request.hostname,
      method: request.method,
      path: request.path,
      headers: request.headers
    }, (res) => {
      let data = '';
      res.on('data', chunk => { data += chunk; });
      res.on('end', () => {
        resolve({
          statusCode: res.statusCode,
          headers: res.headers,
          body: JSON.parse(data)
        });
      });
    });

    req.on('error', (error) => {
      reject(error);
    });

    if (request.body) {
      req.write(request.body);
    }

    req.end();
  });
};


// Function to parse and combine hits into a single string
function combineHits(queryResult) {
    let fullContents = ""; // Initialize an empty string to store combined contents
  
    if (queryResult.hits && queryResult.hits.hits) {
      // Loop over the hits array
      queryResult.hits.hits.forEach(hit => {
        // Convert each hit object to a string and append it to the fullContents
        fullContents += JSON.stringify(hit) + "\n"; // Add a newline for separation
      });
    } else {
      // If no hits, return an appropriate message
      fullContents = "No hits found.";
    }
  
    return fullContents;
  }














// Example Usage:
// queryOpenSearch('day');   // Queries data within the last day
// queryOpenSearch('week');  // Queries data within the last week
// queryOpenSearch('month'); // Queries data within the last month
// queryOpenSearch('year');  // Queries data within the last year
// queryOpenSearch('all');   // Queries all data


const queryOpenSearchResults = await queryOpenSearch('week');  // Queries data within the last week
const queryOpenSearchResultsCombined = await combineHits(queryOpenSearchResults); // Combine the hits into a single string


console.log("queryOpenSearchResultsCombined:", queryOpenSearchResultsCombined);





